Vercel static project.
Upload this folder or connect it through GitHub.
Main file: index.html
